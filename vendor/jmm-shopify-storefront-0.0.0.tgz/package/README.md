# Shopify Storefront adapter

This package contains JMM's bounded, server-only adapter for Shopify's
published catalog, individual published products, guest Cart operations, and
Shopify-hosted checkout handoff. The package root exports inert JMM contracts.
Runtime access is available only through
`@jmm/shopify-storefront/server`. Its explicit Node and React Server conditions
resolve the runtime; browser and unknown runtime conditions fail closed through
a side-effectful denial module so credential-bearing code cannot enter a client
bundle.

## Vendor dependency decision

The adapter pins Shopify's official lightweight
`@shopify/storefront-api-client` at `2.0.0`. Shopify recommends it for custom
storefronts without Hydrogen. It owns the versioned endpoint and private-token
header construction; JMM still owns timeouts, retries, pagination, response
validation, money conversion, error redaction, and the public contract.

Catalog and Cart money reuse `@jmm/domain-contracts` for the exact
minor-unit/currency shape and runtime validation. The adapter still owns Shopify
decimal conversion, the approved JPY policy, and translation into redacted
`StorefrontError` values.

The consequence is one Shopify-maintained transitive GraphQL client that must be
reviewed with the quarterly Storefront API upgrade. The larger Shopify app
framework, GraphQL code generator, retry library, and generic GraphQL abstraction
remain deliberately absent.

## Current boundary

- Storefront API version: `2026-07`, hard-coded and response-checked.
- Declared permissions: `unauthenticated_read_product_listings` and
  `unauthenticated_write_checkouts`. Shopify's write permission includes Cart
  reads, so no redundant checkout-read permission is required. This package
  does not grant or remotely verify either permission.
- Optional recurring-purchase capability: both clients accept
  `sellingPlansEnabled`, default `false`. Enabling requires the separately
  approved `unauthenticated_read_selling_plans` scope. Disabled reads never
  request allocations and disabled mutations reject a selling-plan input.
  `requiresSellingPlan` is always read so subscription-only merchandise cannot
  be treated as a one-time purchase. Applications must bind sealed cart sessions
  to this capability mode; a cart opened under a different mode is not safe to
  reuse because disabled reads cannot inspect an optional subscription line.
- Read operations: `JmmPublishedCatalog`, `JmmPublishedProduct`, `JmmCartRead`,
  and the just-in-time `JmmCartCheckout` lookup.
- Mutation operations: `JmmCartCreate`, `JmmCartLinesAdd`,
  `JmmCartLinesUpdate`, and `JmmCartLinesRemove`. Each accepts one line. The
  transport and Shopify SDK both make exactly one attempt, because replaying an
  ambiguous Cart write could duplicate buyer intent.
- Catalog bound: four requests, 100 products, and 100 variants per product;
  excess or no-progress pagination fails rather than truncating or looping.
- Product-detail bound: one complete product with at most 100 variants. A
  paginated or oversized variant connection fails rather than returning an
  incomplete product. Enabled detail reads include at most 20 selling-plan
  allocations per variant, rejecting truncation. Catalog-list reads do not
  expand allocations; their plan arrays are empty, not evidence that the shop
  has no plans. Fresh detail reads authorize actual purchase choices.
- Cart bound: the complete supported projection for at most 100 top-level
  `CartLine` values. Every Cart operation, including checkout handoff, asks for
  101 lines and fails on the extra line, pagination, duplicate line IDs or
  purchase identities, nested relationships, or a transformed/componentized line instead of
  returning partial state. A purchase identity is a variant plus its optional
  selling plan, so the same variant may be purchased both once and on a plan.
  Mutation inputs cannot set attributes. An enabled create/add accepts an
  opaque `sellingPlanId`; quantity-only updates omit that field to preserve
  the current choice. Cart sessions accept only app-originated sealed
  references. For the supported line model, `totalQuantity` must equal the sum
  of positive returned line quantities.
- The supported plan projection is intentionally narrow: recurring delivery
  and billing intervals/counts must match, the allocation must have one
  constant price equal to its per-delivery price, its initial charge must equal
  that price, and its remaining balance must be zero. A finite/changing price
  phase, prepaid or deferred arrangement is excluded from eligible catalog
  plans. Malformed data fails the read; an unsupported non-null cart allocation
  fails cart/checkout validation rather than becoming a one-time line.
- A successful create must return only the requested variant/plan identity and
  quantity; a smaller quantity is accepted only with a warning for buyer review.
  A successful add must include its requested identity, but the adapter has no
  before snapshot and cannot prove that this line increased or that another
  purchase mode did not increase. The application must compare the preflight
  and returned snapshots before reporting add/update success, including
  requested quantity changes and changes to other plans of the same variant.
  Presence alone is not confirmation that the requested add occurred.
- Cart and checkout reads use the existing bounded retry policy. Mutations do
  not retry; any post-dispatch transport or response-validation failure becomes
  the stable `MUTATION_OUTCOME_UNKNOWN` error so the caller can refresh Cart
  state before another write.
- The complete opaque Cart ID, including Shopify's current key material, is a
  bearer credential. Mapped Cart IDs and checkout URLs remain accessible to
  trusted server code but are non-enumerable and absent from JSON
  serialization. Mutation responses accept a valid rotated Cart ID as the new
  authority.
- Checkout lookup revalidates the same complete bounded Cart projection, then
  validates an absolute HTTPS URL with no credentials or fragment against the
  exact configured host, including a configured non-default port. The
  application must also require a non-empty fresh Cart before redirecting.
- Product handles are accepted only in JMM's canonical 1–255 character form:
  lowercase ASCII letters and digits separated by single hyphens. A handle is a
  mutable route locator, never JMM or cross-system identity; Shopify's opaque
  Product GID remains the external reference.
- Every variant includes Shopify's contextual quantity rule: `minimum` is the
  smallest permitted quantity, nullable `maximum` is the upper bound when one
  exists, and `increment` is the permitted quantity step. The adapter validates
  positive safe integers and divisibility but does not reinterpret those values
  as approved JMM pack, MOQ, or volume-pricing policy.
- Currency policy for the approved smoke environment: JPY with zero minor digits.
- Numeric inventory (`quantityAvailable`), quantity price breaks, contextual
  markets, customers, Admin API, generic or bulk writes, caching, UI wiring,
  price per kilogram, and Shopify payload logging are out of scope.

The private access token is intentionally non-enumerable in parsed configuration.
The adapter never logs and its errors retain no cause, request, header, response
body, GraphQL message, or raw value.

See [the smoke-test runbook](../../docs/runbooks/shopify-storefront-smoke.md).

## Selling-plan documentation and verification

TASK-0156 uses the official Storefront `2026-07` contracts for
[allocations](https://shopify.dev/docs/api/storefront/2026-07/objects/SellingPlanAllocation),
[recurring billing](https://shopify.dev/docs/api/storefront/2026-07/objects/SellingPlanRecurringBillingPolicy),
[recurring delivery](https://shopify.dev/docs/api/storefront/2026-07/objects/SellingPlanRecurringDeliveryPolicy),
[price phases](https://shopify.dev/docs/api/storefront/2026-07/objects/SellingPlanPriceAdjustment),
and [Cart line input](https://shopify.dev/docs/api/storefront/2026-07/input-objects/CartLineInput).
The [headless subscription guide](https://shopify.dev/docs/storefronts/headless/building-with-the-storefront-api/products-collections/subscriptions)
documents the additional read scope and using the Cart workflow.

A minimal read-only probe on 2026-09-21 returned API version `2026-07`, HTTP
200 and `ACCESS_DENIED` for selling-plan reads. Eligible plan counts and terms
therefore remain unknown. No remote mutation or permission change occurred.
Test merchandise does not prove the target store is a development store;
SHOP-001 still requires environment classification before remote writes.
