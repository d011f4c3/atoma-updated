# Shared domain contracts

`@jmm/domain-contracts` is JMM's dependency-free representation boundary for
values exchanged by adapters, application modules, and future persistence
readers. It currently provides:

- distinct validated Workspace, Party, Location, Product, SKU, Supplier, Lot,
  Reservation, Allocation, Order, and OrderLine UUID brands;
- nonnegative exact JSON integers for minor currency units and grams;
- strict money values backed by an explicitly reviewed currency policy;
- canonical fixed-microsecond UTC instant strings; and
- redacted, stable validation errors.

The package performs no arithmetic, conversion, normalization, I/O, logging, or
vendor-specific work. It does not prove database existence or authorization.
Parse untrusted values when they enter a boundary, keep brands internal, and use
the serializers before emitting JSON so asserted values are checked again.

`SupplierId` remains a legacy identity contract for the historical Supplier
foundation. It is deliberately not interchangeable with `PartyId`: Supplier is
a scoped Party role or relationship in the v2 model, not the canonical Party
identity.

`LocationId` identifies a stable physical place inside a Workspace. It does not
encode facility ownership, Location operation, inventory ownership, custody,
address, or physical stock.

Currency policy is explicit. An uppercase three-letter code is only a lexical
invariant; the owning adapter must separately review that code and its exponent
against the current authoritative currency specification.

See [ADR-0005](../../docs/adr/0005-runtime-value-encoding.md),
[ADR-0006](../../docs/adr/0006-supplier-and-lot-identities.md),
[ADR-0009](../../docs/adr/0009-assumption-gated-reservation-allocation-holds.md),
[ADR-0010](../../docs/adr/0010-assumption-gated-shopify-order-snapshots.md),
[ADR-0015](../../docs/adr/0015-v2-client-direction-and-reconciliation-boundary.md),
[ADR-0016](../../docs/adr/0016-single-postgres-authority-with-separated-application-boundaries.md),
[TASK-0004](../../docs/tasks/0004-shared-domain-contracts.md),
[TASK-0005](../../docs/tasks/0005-supply-identity-foundation.md),
[TASK-0008](../../docs/tasks/0008-reservation-allocation-holds.md), and
[TASK-0009](../../docs/tasks/0009-shopify-order-snapshots.md),
[TASK-0055](../../docs/tasks/0055-workspace-party-identity-kernel.md), and
[TASK-0123](../../docs/tasks/0123-workspace-location-identity-kernel.md).
